<!-- Mainly scripts -->
<script src="assets/js/jquery-3.1.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="assets/js/inspinia.js"></script>
<script src="assets/js/plugins/pace/pace.min.js"></script>


<!-- Jasny -->
<script src="assets/js/plugins/jasny/jasny-bootstrap.min.js"></script>

<!-- DROPZONE -->
<script src="assets/js/plugins/dropzone/dropzone.js"></script>

<!-- CodeMirror -->
<script src="assets/js/plugins/codemirror/codemirror.js"></script>
<script src="assets/js/plugins/codemirror/mode/xml/xml.js"></script>
