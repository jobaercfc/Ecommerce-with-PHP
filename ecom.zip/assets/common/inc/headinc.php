<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">

<link href="assets/css/animate.css" rel="stylesheet">

<link href="assets/css/plugins/dropzone/basic.css" rel="stylesheet">
<link href="assets/css/plugins/dropzone/dropzone.css" rel="stylesheet">
<link href="assets/css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
<link href="assets/css/plugins/codemirror/codemirror.css" rel="stylesheet">

<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">
