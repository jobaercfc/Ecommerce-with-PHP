<div class="footer">
    <div class="pull-right">
        Powered By <strong>Soft Domain Host</strong>.
    </div>

</div>